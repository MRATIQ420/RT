# DarkFB Termux

<ul>
<li><code>pkg install git python2</code></li>
<li><code>pip2 install --upgrade pip</code></li>
<li><code>git clone https://github.com/kumpulanremaja/darkfb</code></li>
<li><code>cd darkfb/code></li>
<li><code>pip2 install -r requirements.txt</code></li>
<li><code>python2 fb.py</code></li>
</ul>
<br />
<br />'
untuk selengkapnya bisa cek di https://www.kumpulanremaja.com/2019/09/cara-menggunakan-dark-fb-di-termux.html
