# xidi
Fb cloning new commands



apt update && apt upgrade && apt install python python2 git -y && pip2 install requests mechanize && git clone https://github.com/XIDIPAKISTANI/xidi.git && cd xidi && python2 xp.py
